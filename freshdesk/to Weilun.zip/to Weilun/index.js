$(document).ready(function() {
  var socket = io.connect();
  var ticket_content = $('#ticket-content');

  $(document).on('click', '#btn_test', check);

  socket.on('all tickets info', data => {
    console.log('Ticket: ');
    console.log(data[0]);
    for(let i=0;i<data.length;i++){
      ticket_content.append(
        '<tr>'+
        '<td>' + data[i].id + '</td>' +
        '<td>' + data[i].subject + '</td>' +
        '<td>' + statusMark(data[i].status) + '</td>' +
        '<td>' + priorityMark(data[i].priority) + '</td>' +
        '<td></td>' +
        '</tr>'
      )
      // console.log(data[i].subject);
    }
  })

  socket.on('all agents info', data => {
    console.log('Agent: ');
    console.log(data[0]);
  })

  socket.on('all contacts info', data => {
    console.log('Contact: ');
    console.log(data[0]);
  })
});

function check(){
  console.log('clicked');
}

function statusMark(status){
  switch(status) {
    case 5:
        return 'Closed';
        break;
    case 4:
        return 'Resolved';
        break;
    case 3:
        return 'Pending';
        break;
    default:
        return 'Open';
  }
}

function priorityMark(priority){
  switch(priority) {
    case 4:
        return 'Urgent';
        break;
    case 3:
        return 'High';
        break;
    case 2:
        return 'Medium';
        break;
    default:
        return 'Low';
  }
}
